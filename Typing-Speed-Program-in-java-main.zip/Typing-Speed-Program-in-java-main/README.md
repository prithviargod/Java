<h1 align="center">Typing Speed Program in Java</h1>
 
Typing Speed Program to check the speed of typing in word per minute(WPM).
  
<!-- TABLE OF CONTENTS -->

## Table of Contents

- [Overview](#overview) 
- [Explanation ](#explanation) 

## Overview


## Explanation 

First, count all typed characters and divide by five to get the number of words typed.
To give an example, 
- if you typed 200 characters in 1 minute, your net wpm typing speed would be (200 characters / 5) / 1 min = 40 WPM.

- If you typed 200 characters in 30 seconds. Your net speed would be (200/5) / 0.5 = 80 WPM.
	
###  (number of Characters / 5) / 1 minutes = num WPM
